/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dam.m06.uf1.Dades;

import dam.m06.uf1.Aplicacio.Model.Equips;
import java.io.File;

/**
 *
 * @author manel
 */
public class CSV {
    
    /**
     * Exporta tots els equips a un fitxer CSV
     * @param fitx
     * @param dades
     * @throws DadesException 
     */
    public static void exportaEquipsACSV(File fitx, Equips dades) throws DadesException
    {
        throw new DadesException("No implementat");
    }
    
    /**
     * Exporta tots els jugadors a un fitxer CSV
     * @param fitx
     * @param dades
     * @throws DadesException 
     */
    public static void exportaJugadorsACSV(File fitx, Equips dades) throws DadesException
    {
      throw new DadesException("No implementat");
    }
}
