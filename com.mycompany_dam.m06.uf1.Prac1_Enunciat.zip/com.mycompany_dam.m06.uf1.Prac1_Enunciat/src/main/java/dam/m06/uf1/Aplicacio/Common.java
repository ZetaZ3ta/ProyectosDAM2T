/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dam.m06.uf1.Aplicacio;

import java.net.URL;

/**
 *
 * @author manel
 */
public class Common {
    
    /**
     * Retorna la predicció del temps d'una determinada ciutat durant 
     * uns certs dies
     * @param fitxXML
     * @return
     * @throws AplicacioException
     */
    public static String retornaTempsCiutat(URL fitxXML) throws AplicacioException
    {
       String ret = "";
       
       if (true) throw new AplicacioException("No implementat");
        
       return ret;
    }
}
